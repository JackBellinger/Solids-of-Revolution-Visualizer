# Mixed Reality Toolkit - SDK - Elements - Textures

This folder contains all the individual texture assets used to build MRTK solutions