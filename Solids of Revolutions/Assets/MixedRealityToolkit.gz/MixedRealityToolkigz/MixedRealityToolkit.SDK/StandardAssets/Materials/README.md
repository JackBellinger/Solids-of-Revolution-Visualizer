# Mixed Reality Toolkit - SDK - Elements - Materials

This folder contains all the individual material assets used to build MRTK solutions