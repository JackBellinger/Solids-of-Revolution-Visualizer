# Mixed Reality Toolkit - SDK - Elements - Models

This folder contains all the individual model assets used to build MRTK solutions