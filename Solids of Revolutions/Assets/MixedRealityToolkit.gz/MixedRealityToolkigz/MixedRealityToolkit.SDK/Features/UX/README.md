# Mixed Reality Toolkit - SDK - UX

This folder contains all the individual assets used to build MRTK solutions