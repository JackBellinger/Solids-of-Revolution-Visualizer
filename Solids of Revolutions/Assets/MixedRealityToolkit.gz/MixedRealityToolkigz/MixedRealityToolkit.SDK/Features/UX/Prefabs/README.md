# Mixed Reality Toolkit - SDK - UX - Prefabs

This folder contains all the individual prefab assets used to build MRTK solutions