﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.

using System.Reflection;

[assembly: AssemblyVersion("2.3.0.0")]
[assembly: AssemblyFileVersion("2.3.0.0")]

[assembly: AssemblyProduct("Microsoft® Mixed Reality Toolkit SDK")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation")]
