﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Reflection;

[assembly: AssemblyVersion("2.3.0.0")]
[assembly: AssemblyFileVersion("2.3.0.0")]

[assembly: AssemblyProduct("Microsoft® Mixed Reality Toolkit Providers")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation")]
