# Microsoft.MixedReality.Toolkit.Providers.UnityAR

This folder contains the code to enable mobile AR, via Unity AR Foundation, on MRTK.
